<?php
	if($nrp=="") exit;
	$h=$this->mhs_absensi_model->insert_new($nrp,$id);